import ChannelCreate from './ChannelCreate';

export default ChannelCreate;