import SourceCard from './SourceCard';

export default SourceCard;