import ChannelTable from './ChannelTable';

export default ChannelTable;