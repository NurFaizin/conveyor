// Global
const status = {
  FAIL: 'status/type/FAIL',
  IN_PROGRESS: 'status/type/IN_PROGRESS',
  COMPLETE: 'status/type/COMPLETE',
};
export default status;
